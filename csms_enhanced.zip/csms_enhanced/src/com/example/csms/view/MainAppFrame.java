package com.example.csms.view;

import com.example.csms.exception.DataAccessException;
import com.example.csms.model.Statut; // Import Statut
import com.example.csms.model.Station;
import com.example.csms.service.StationService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn; // Pour le renderer
import javax.swing.table.TableRowSorter; // Pour le tri
import java.awt.*;
import java.util.List;
import java.util.Map; // Pour les stats
import java.util.Optional;
import java.util.Vector;

public class MainAppFrame extends JFrame {

    private final StationService stationService;
    private JTable stationTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchButton;
    private JButton refreshButton;
    private JButton viewDetailsButton; // Nouveau bouton
    private TableRowSorter<DefaultTableModel> sorter;

    // Labels pour les statistiques
    private JLabel totalStationsLabel;
    private JLabel availableStationsLabel;
    private JLabel chargingStationsLabel;
    private JLabel outOfServiceStationsLabel;

    public MainAppFrame() {
        this.stationService = new StationService();

        setTitle("Gestionnaire de Stations de Charge v0.2"); // Version mise à jour
        setSize(950, 700); // Taille légèrement augmentée
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Menu Bar ---
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Fichier");
        JMenuItem exitItem = new JMenuItem("Quitter");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        // On pourrait ajouter un menu Aide -> A Propos ici
        setJMenuBar(menuBar);

        // --- Table Model et JTable ---
        // Ajout "Dernière MàJ"
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nom", "Localisation", "Statut", "Dernière MàJ"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 4) return java.sql.Timestamp.class;
                // Permet au renderer de savoir que la colonne 3 est un String
                if (columnIndex == 3) return String.class;
                return super.getColumnClass(columnIndex);
            }
        };
        stationTable = new JTable(tableModel);
        stationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        stationTable.setAutoCreateRowSorter(true);
        stationTable.setFillsViewportHeight(true);
        stationTable.setRowHeight(25); // Augmente hauteur ligne pour visibilité

        // Appliquer le renderer de couleur pour la colonne "Statut" (index 3)
        TableColumn statusColumn = stationTable.getColumnModel().getColumn(3);
        statusColumn.setCellRenderer(new StatusCellRenderer()); // Applique notre renderer personnalisé

        sorter = new TableRowSorter<>(tableModel);
        stationTable.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(stationTable);

        // --- Panneau de Contrôle (Haut) ---
        JPanel controlPanel = new JPanel(new BorderLayout(10, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Marges augmentées

        // Panneau de recherche (gauche)
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Rechercher:"));
        searchField = new JTextField(25); // Champ plus large
        searchButton = new JButton("Chercher");
        JButton clearSearchButton = new JButton("Effacer");
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearSearchButton);

        // Panneau boutons d'action (droite)
        JPanel actionButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshButton = new JButton("Rafraîchir");
        viewDetailsButton = new JButton("Voir Détails"); // Nouveau bouton
        actionButtonPanel.add(refreshButton);
        actionButtonPanel.add(viewDetailsButton); // Ajout du bouton

        controlPanel.add(searchPanel, BorderLayout.WEST);
        controlPanel.add(actionButtonPanel, BorderLayout.EAST);


        // --- Panneau de Statistiques (en dessous du contrôle) ---
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Statistiques")); // Ajoute un titre
        totalStationsLabel = new JLabel("Total: ?");
        availableStationsLabel = new JLabel("Disponibles: ?");
        chargingStationsLabel = new JLabel("En Charge: ?");
        outOfServiceStationsLabel = new JLabel("Hors Service: ?");
        // Met des marges entre les labels
        statsPanel.add(totalStationsLabel);
        statsPanel.add(Box.createHorizontalStrut(15)); // Espace
        statsPanel.add(availableStationsLabel);
        statsPanel.add(Box.createHorizontalStrut(15));
        statsPanel.add(chargingStationsLabel);
        statsPanel.add(Box.createHorizontalStrut(15));
        statsPanel.add(outOfServiceStationsLabel);

        // Regroupe controlPanel et statsPanel dans un panel nord
        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.add(controlPanel, BorderLayout.NORTH);
        northPanel.add(statsPanel, BorderLayout.SOUTH);


        // --- Panneau de Boutons CRUD (Bas) ---
        JPanel crudButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        crudButtonPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0)); // Marge en bas
        JButton addButton = new JButton("Ajouter Station");
        JButton editButton = new JButton("Modifier Sélection");
        JButton deleteButton = new JButton("Supprimer Sélection");

        crudButtonPanel.add(addButton);
        crudButtonPanel.add(editButton);
        crudButtonPanel.add(deleteButton);

        // --- Layout Principal ---
        setLayout(new BorderLayout(0, 5));
        add(northPanel, BorderLayout.NORTH); // Utilise le panel regroupé
        add(scrollPane, BorderLayout.CENTER);
        add(crudButtonPanel, BorderLayout.SOUTH);

        // --- Actions ---
        refreshButton.addActionListener(e -> chargerDonneesStations(null));
        addButton.addActionListener(e -> ouvrirDialogueStation(null));
        editButton.addActionListener(e -> ouvrirDialogueStationSelectionnee(false)); // false = mode édition
        deleteButton.addActionListener(e -> supprimerStationSelectionnee());
        viewDetailsButton.addActionListener(e -> ouvrirDialogueStationSelectionnee(true)); // true = mode vue détails
        searchButton.addActionListener(e -> effectuerRecherche());
        searchField.addActionListener(e -> effectuerRecherche());
        clearSearchButton.addActionListener(e -> {
            searchField.setText("");
            chargerDonneesStations(null);
        });

        // Charge les données initiales
        chargerDonneesStations(null);
    }

    // Charge ou recharge les données et met à jour les statistiques
    private void chargerDonneesStations(String critereRecherche) {
        // Efface la table avant de la remplir
        tableModel.setRowCount(0);
        String currentSearch = (critereRecherche != null) ? critereRecherche : searchField.getText(); // Garde le critère actuel

        try {
            List<Station> stations;
            if (currentSearch != null && !currentSearch.trim().isEmpty()) {
                stations = stationService.rechercherStations(currentSearch);
                if (stations.isEmpty() && critereRecherche != null) { // Affiche seulement si c'était une nouvelle recherche
                    JOptionPane.showMessageDialog(this, "Aucune station trouvée pour '" + currentSearch + "'.", "Recherche", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                stations = stationService.trouverToutesLesStations();
            }

            if (stations != null) {
                for (Station station : stations) {
                    Vector<Object> row = new Vector<>();
                    row.add(station.getId());
                    row.add(station.getNom());
                    row.add(station.getLocalisation());
                    row.add(station.getStatut() != null ? station.getStatut().getDescription() : "N/D");
                    row.add(station.getDerniereMiseAJour());
                    tableModel.addRow(row);
                }
            }
            // Mettre à jour les statistiques après avoir chargé les données
            mettreAJourStatistiques();

        } catch (DataAccessException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du chargement des données des stations:\n" + e.getMessage(),
                    "Erreur Base de Données", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            mettreAJourStatistiquesErreur(); // Met les stats en erreur
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Une erreur inattendue est survenue:\n" + e.getMessage(),
                    "Erreur Inattendue", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            mettreAJourStatistiquesErreur();
        }
    }

    // Ouvre le dialogue pour ajouter ou modifier une station
    private void ouvrirDialogueStation(Station stationAModifier) {
        StationDialog dialog = new StationDialog(this, stationService, stationAModifier);
        dialog.setVisible(true);
        if (dialog.isSucces()) {
            chargerDonneesStations(null); // Recharge tout après modif/ajout
            searchField.setText(""); // Efface la recherche potentielle
        }
    }

    // Ouvre le dialogue pour voir les détails ou modifier la station sélectionnée
    private void ouvrirDialogueStationSelectionnee(boolean voirSeulement) {
        int selectedRowView = stationTable.getSelectedRow(); // Index dans la vue (peut être triée/filtrée)
        if (selectedRowView == -1) {
            String action = voirSeulement ? "voir les détails" : "modifier";
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une station pour " + action + ".", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Convertit l'index de la vue en index du modèle de données sous-jacent
        int selectedRowModel = stationTable.convertRowIndexToModel(selectedRowView);
        long idStation = (long) tableModel.getValueAt(selectedRowModel, 0);

        try {
            Optional<Station> stationOpt = stationService.trouverStationParId(idStation);
            if (stationOpt.isPresent()) {
                if (voirSeulement) {
                    // Ouvre le nouveau dialogue de détails (lecture seule)
                    StationDetailsDialog detailsDialog = new StationDetailsDialog(this, stationOpt.get());
                    detailsDialog.setVisible(true);
                } else {
                    // Ouvre l'ancien dialogue en mode édition
                    ouvrirDialogueStation(stationOpt.get());
                }
            } else {
                JOptionPane.showMessageDialog(this, "La station sélectionnée n'existe plus.", "Erreur", JOptionPane.ERROR_MESSAGE);
                chargerDonneesStations(searchField.getText());
            }
        } catch(DataAccessException e) {
            JOptionPane.showMessageDialog(this, "Erreur BDD lors de la récupération de la station:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Supprime la station sélectionnée
    private void supprimerStationSelectionnee() {
        int selectedRowView = stationTable.getSelectedRow();
        if (selectedRowView == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une station à supprimer.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int selectedRowModel = stationTable.convertRowIndexToModel(selectedRowView);
        long idStation = (long) tableModel.getValueAt(selectedRowModel, 0);
        String nomStation = (String) tableModel.getValueAt(selectedRowModel, 1);

        int confirmation = JOptionPane.showConfirmDialog(this,
                "Confirmer la suppression de la station '" + nomStation + "' (ID: " + idStation + ") ?",
                "Confirmation Suppression", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirmation == JOptionPane.YES_OPTION) {
            try {
                boolean deleted = stationService.supprimerStation(idStation);
                if (deleted) {
                    JOptionPane.showMessageDialog(this, "Station supprimée avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
                    chargerDonneesStations(searchField.getText()); // Rafraîchit
                } else {
                    JOptionPane.showMessageDialog(this, "La station n'a pas pu être supprimée.", "Échec", JOptionPane.WARNING_MESSAGE);
                }
            } catch (DataAccessException e) {
                JOptionPane.showMessageDialog(this, "Erreur BDD lors de la suppression:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur inattendue lors de la suppression:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    // Lance une recherche dans la BDD
    private void effectuerRecherche() {
        String critere = searchField.getText();
        chargerDonneesStations(critere); // Recharge les données avec le critère
    }

    // Met à jour les labels de statistiques
    private void mettreAJourStatistiques() {
        try {
            Map<String, Long> stats = stationService.getStationStatistics();
            totalStationsLabel.setText("Total: " + stats.getOrDefault("TOTAL", 0L));
            availableStationsLabel.setText("Disponibles: " + stats.getOrDefault(Statut.DISPONIBLE.name(), 0L));
            chargingStationsLabel.setText("En Charge: " + stats.getOrDefault(Statut.EN_CHARGE.name(), 0L));
            outOfServiceStationsLabel.setText("Hors Service: " + stats.getOrDefault(Statut.HORS_SERVICE.name(), 0L));
        } catch (DataAccessException e) {
            System.err.println("Erreur lors de la récupération des statistiques: " + e.getMessage());
            mettreAJourStatistiquesErreur(); // Affiche 'Erreur' si la récupération échoue
            e.printStackTrace();
        }
    }

    // Met les labels de stats en mode erreur
    private void mettreAJourStatistiquesErreur() {
        totalStationsLabel.setText("Total: Erreur");
        availableStationsLabel.setText("Disponibles: Erreur");
        chargingStationsLabel.setText("En Charge: Erreur");
        outOfServiceStationsLabel.setText("Hors Service: Erreur");
    }
}
package com.example.csms.service;

import com.example.csms.dao.StationDAO;
import com.example.csms.dao.impl.StationDAOImpl; // Utilise l'implémentation
import com.example.csms.exception.DataAccessException;
import com.example.csms.model.Statut; // Import Statut
import com.example.csms.model.Station;

import java.util.Collections;
import java.util.HashMap; // Pour les statistiques
import java.util.List;
import java.util.Map; // Pour les statistiques
import java.util.Optional;
import java.util.stream.Collectors; // Pour les statistiques

public class StationService {

    private final StationDAO stationDAO;

    public StationService() {
        this.stationDAO = new StationDAOImpl(); // Instanciation directe
    }

    // Constructeur pour injection (tests)
    public StationService(StationDAO stationDAO) {
        this.stationDAO = stationDAO;
    }

    public Station ajouterStation(Station station) throws DataAccessException {
        if (station == null || station.getNom() == null || station.getNom().trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom de la station ne peut pas être vide.");
        }
        return stationDAO.ajouterStation(station);
    }

    public boolean modifierStation(Station station) throws DataAccessException {
        if (station == null || station.getId() <= 0 || station.getNom() == null || station.getNom().trim().isEmpty()) {
            throw new IllegalArgumentException("Données de station invalides pour la modification.");
        }
        return stationDAO.modifierStation(station);
    }

    public boolean supprimerStation(long id) throws DataAccessException {
        if (id <= 0) {
            throw new IllegalArgumentException("ID de station invalide pour la suppression.");
        }
        return stationDAO.supprimerStation(id);
    }

    public Optional<Station> trouverStationParId(long id) throws DataAccessException {
        if (id <= 0) {
            return Optional.empty();
        }
        return stationDAO.trouverStationParId(id);
    }

    public List<Station> trouverToutesLesStations() throws DataAccessException {
        try {
            return stationDAO.trouverToutesLesStations();
        } catch (DataAccessException e) {
            System.err.println("Erreur service: impossible de récupérer les stations: " + e.getMessage());
            return Collections.emptyList(); // Retourne liste vide en cas d'erreur
        }
    }

    public List<Station> rechercherStations(String critere) throws DataAccessException {
        if (critere == null || critere.trim().isEmpty()) {
            return trouverToutesLesStations(); // Si recherche vide, retourne tout
        }
        try {
            return stationDAO.rechercherStations(critere.trim());
        } catch (DataAccessException e) {
            System.err.println("Erreur service: impossible de rechercher les stations: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Calcule les statistiques sur les statuts des stations.
     * @return Une Map contenant le nombre de stations pour chaque statut et une clé "TOTAL".
     * @throws DataAccessException Si une erreur BDD survient.
     */
    public Map<String, Long> getStationStatistics() throws DataAccessException {
        List<Station> stations = trouverToutesLesStations(); // Réutilise la méthode existante
        Map<String, Long> stats = new HashMap<>();

        // Initialise les compteurs pour tous les statuts possibles
        for (Statut s : Statut.values()) {
            stats.put(s.name(), 0L); // Utilise le nom de l'enum comme clé
        }

        // Compte les stations par statut
        Map<Statut, Long> countsByStatus = stations.stream()
                .filter(s -> s.getStatut() != null) // Ignore les statuts null potentiels
                .collect(Collectors.groupingBy(Station::getStatut, Collectors.counting()));

        // Met à jour la map de statistiques
        stats.putAll(countsByStatus.entrySet().stream()
                .collect(Collectors.toMap(e -> e.getKey().name(), Map.Entry::getValue)));

        // Ajoute le total
        stats.put("TOTAL", (long) stations.size());

        return stats;
    }
}
package com.example.csms.service;

import com.example.csms.dao.StationDAO;
import com.example.csms.dao.impl.StationDAOImpl; // Utilise l'implémentation
import com.example.csms.exception.DataAccessException;
import com.example.csms.model.Station;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class StationService {

    private final StationDAO stationDAO;

    public StationService() {
        this.stationDAO = new StationDAOImpl(); // Instanciation directe
    }

    // Constructeur pour injection (tests)
    public StationService(StationDAO stationDAO) {
        this.stationDAO = stationDAO;
    }

    public Station ajouterStation(Station station) throws DataAccessException {
        if (station == null || station.getNom() == null || station.getNom().trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom de la station ne peut pas être vide.");
        }
        // Autres validations possibles ici
        return stationDAO.ajouterStation(station);
    }

    public boolean modifierStation(Station station) throws DataAccessException {
        if (station == null || station.getId() <= 0 || station.getNom() == null || station.getNom().trim().isEmpty()) {
            throw new IllegalArgumentException("Données de station invalides pour la modification.");
        }
        return stationDAO.modifierStation(station);
    }

    public boolean supprimerStation(long id) throws DataAccessException {
        if (id <= 0) {
            throw new IllegalArgumentException("ID de station invalide pour la suppression.");
        }
        return stationDAO.supprimerStation(id);
    }

    public Optional<Station> trouverStationParId(long id) throws DataAccessException {
        if (id <= 0) {
            return Optional.empty();
        }
        return stationDAO.trouverStationParId(id);
    }

    public List<Station> trouverToutesLesStations() throws DataAccessException {
        try {
            return stationDAO.trouverToutesLesStations();
        } catch (DataAccessException e) {
            System.err.println("Erreur service: impossible de récupérer les stations: " + e.getMessage());
            return Collections.emptyList(); // Retourne liste vide en cas d'erreur
        }
    }

    public List<Station> rechercherStations(String critere) throws DataAccessException {
        if (critere == null || critere.trim().isEmpty()) {
            return trouverToutesLesStations(); // Si recherche vide, retourne tout
        }
        try {
            return stationDAO.rechercherStations(critere.trim());
        } catch (DataAccessException e) {
            System.err.println("Erreur service: impossible de rechercher les stations: " + e.getMessage());
            return Collections.emptyList();
        }
    }
}
package com.example.csms.view;

import com.example.csms.exception.DataAccessException;
import com.example.csms.model.Station;
import com.example.csms.service.StationService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter; // Pour le tri
import java.awt.*;
import java.util.List;
import java.util.Optional;
import java.util.Vector;

public class MainAppFrame extends JFrame {

    private final StationService stationService;
    private JTable stationTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchButton;
    private JButton refreshButton;
    private TableRowSorter<DefaultTableModel> sorter; // Pour le tri des colonnes

    public MainAppFrame() {
        this.stationService = new StationService();

        setTitle("Gestionnaire de Stations de Charge - Connecté");
        setSize(900, 650); // Taille augmentée
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrer

        // --- Menu Bar (Optionnel mais bonne pratique) ---
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("Fichier");
        JMenuItem exitItem = new JMenuItem("Quitter");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // --- Table Model et JTable ---
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nom", "Localisation", "Statut", "Dernière MàJ"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; } // Non éditable

            // Pour afficher correctement les Timestamps (optionnel mais mieux)
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 4) return java.sql.Timestamp.class;
                return super.getColumnClass(columnIndex);
            }
        };
        stationTable = new JTable(tableModel);
        stationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        stationTable.setAutoCreateRowSorter(true); // Active le tri par clic sur l'en-tête
        stationTable.setFillsViewportHeight(true); // La table remplit la hauteur du scrollpane

        // Configuration du sorter pour le filtrage texte
        sorter = new TableRowSorter<>(tableModel);
        stationTable.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(stationTable);

        // --- Panneau de Contrôle (Haut) ---
        JPanel controlPanel = new JPanel(new BorderLayout(10, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Marges

        // Panneau de recherche
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Rechercher:"));
        searchField = new JTextField(20);
        searchButton = new JButton("Chercher");
        JButton clearSearchButton = new JButton("Effacer");
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearSearchButton);

        // Panneau boutons d'action (droite)
        JPanel actionButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshButton = new JButton("Rafraîchir");
        actionButtonPanel.add(refreshButton);

        controlPanel.add(searchPanel, BorderLayout.WEST);
        controlPanel.add(actionButtonPanel, BorderLayout.EAST);


        // --- Panneau de Boutons CRUD (Bas) ---
        JPanel crudButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        crudButtonPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        JButton addButton = new JButton("Ajouter Station");
        JButton editButton = new JButton("Modifier Sélection");
        JButton deleteButton = new JButton("Supprimer Sélection");

        crudButtonPanel.add(addButton);
        crudButtonPanel.add(editButton);
        crudButtonPanel.add(deleteButton);

        // --- Layout Principal ---
        setLayout(new BorderLayout(0, 5)); // BorderLayout pour la frame
        add(controlPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(crudButtonPanel, BorderLayout.SOUTH);

        // --- Actions ---
        refreshButton.addActionListener(e -> chargerDonneesStations(null)); // null = charger tout
        addButton.addActionListener(e -> ouvrirDialogueStation(null)); // null = ajout
        editButton.addActionListener(e -> ouvrirDialogueStationSelectionnee());
        deleteButton.addActionListener(e -> supprimerStationSelectionnee());
        searchButton.addActionListener(e -> effectuerRecherche());
        searchField.addActionListener(e -> effectuerRecherche()); // Recherche avec Entrée
        clearSearchButton.addActionListener(e -> {
            searchField.setText("");
            chargerDonneesStations(null); // Recharge tout
            // Alternative: effacer le filtre local si on utilisait le sorter pour filtrer
            // sorter.setRowFilter(null);
        });

        // Charge les données initiales
        chargerDonneesStations(null);
    }

    // Charge ou recharge les données dans la table
    private void chargerDonneesStations(String critereRecherche) {
        tableModel.setRowCount(0); // Efface la table
        try {
            List<Station> stations;
            if (critereRecherche != null && !critereRecherche.trim().isEmpty()) {
                stations = stationService.rechercherStations(critereRecherche);
                if (stations.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Aucune station trouvée pour '" + critereRecherche + "'.", "Recherche", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                stations = stationService.trouverToutesLesStations();
            }

            if (stations != null) {
                for (Station station : stations) {
                    Vector<Object> row = new Vector<>();
                    row.add(station.getId());
                    row.add(station.getNom());
                    row.add(station.getLocalisation());
                    row.add(station.getStatut() != null ? station.getStatut().getDescription() : "N/D");
                    row.add(station.getDerniereMiseAJour()); // Ajout timestamp
                    tableModel.addRow(row);
                }
            }
        } catch (DataAccessException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du chargement des données des stations:\n" + e.getMessage(),
                    "Erreur Base de Données", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Une erreur inattendue est survenue:\n" + e.getMessage(),
                    "Erreur Inattendue", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Ouvre le dialogue pour ajouter ou modifier une station
    private void ouvrirDialogueStation(Station stationAModifier) {
        // Crée un nouveau dialogue à chaque fois
        StationDialog dialog = new StationDialog(this, stationService, stationAModifier);
        dialog.setVisible(true); // Affiche le dialogue modal

        // Si le dialogue a indiqué un succès, on rafraîchit la table
        if (dialog.isSucces()) {
            chargerDonneesStations(searchField.getText()); // Recharge en tenant compte de la recherche
        }
    }

    // Ouvre le dialogue pour la station sélectionnée
    private void ouvrirDialogueStationSelectionnee() {
        int selectedRow = stationTable.convertRowIndexToModel(stationTable.getSelectedRow()); // Important avec le tri/filtre
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une station à modifier.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        long idStation = (long) tableModel.getValueAt(selectedRow, 0);
        try {
            Optional<Station> stationOpt = stationService.trouverStationParId(idStation);
            if (stationOpt.isPresent()) {
                ouvrirDialogueStation(stationOpt.get()); // Ouvre le dialogue avec les données
            } else {
                JOptionPane.showMessageDialog(this, "La station sélectionnée n'existe plus.", "Erreur", JOptionPane.ERROR_MESSAGE);
                chargerDonneesStations(searchField.getText()); // Rafraîchit
            }
        } catch(DataAccessException e) {
            JOptionPane.showMessageDialog(this, "Erreur BDD lors de la récupération de la station:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    // Supprime la station sélectionnée
    private void supprimerStationSelectionnee() {
        int selectedRow = stationTable.convertRowIndexToModel(stationTable.getSelectedRow());
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une station à supprimer.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        long idStation = (long) tableModel.getValueAt(selectedRow, 0);
        String nomStation = (String) tableModel.getValueAt(selectedRow, 1);

        int confirmation = JOptionPane.showConfirmDialog(this,
                "Confirmer la suppression de la station '" + nomStation + "' (ID: " + idStation + ") ?",
                "Confirmation Suppression", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirmation == JOptionPane.YES_OPTION) {
            try {
                boolean deleted = stationService.supprimerStation(idStation);
                if (deleted) {
                    JOptionPane.showMessageDialog(this, "Station supprimée avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
                    chargerDonneesStations(searchField.getText()); // Rafraîchit
                } else {
                    // Normalement géré par l'exception, mais sécurité supplémentaire
                    JOptionPane.showMessageDialog(this, "La station n'a pas pu être supprimée (peut-être déjà supprimée ?).", "Échec", JOptionPane.WARNING_MESSAGE);
                }
            } catch (DataAccessException e) {
                JOptionPane.showMessageDialog(this, "Erreur BDD lors de la suppression:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur inattendue lors de la suppression:\n" + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    // Lance une recherche dans la BDD et met à jour la table
    private void effectuerRecherche() {
        String critere = searchField.getText();
        // On recharge les données en filtrant côté serveur (BDD)
        chargerDonneesStations(critere);

        // Alternative: Filtrage côté client (moins efficace si bcp de données)
         /*
         String text = searchField.getText();
         if (text.trim().length() == 0) {
             sorter.setRowFilter(null); // Pas de filtre
         } else {
             // Crée un filtre insensible à la casse sur toutes les colonnes (ou spécifier les colonnes)
             try {
                  sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(text)));
             } catch (java.util.regex.PatternSyntaxException e) {
                  // Gérer l'erreur si le texte n'est pas une regex valide (ne devrait pas arriver avec quote)
                  System.err.println("Erreur de syntaxe du filtre: " + e.getMessage());
                  sorter.setRowFilter(null);
             }
         }
         */
    }
}